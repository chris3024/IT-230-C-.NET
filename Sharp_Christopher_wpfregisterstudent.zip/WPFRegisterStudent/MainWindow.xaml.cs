﻿/* Name: Christopher Sharp
 * Date: 2/22/2025
 * Class: IT 230: Software Development with C#.NET
 * Professor: John Wetsch
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFRegisterStudent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Course choice;
        
        // added variable to collect the total credit hours registered
        private int creditHours;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");


            this.comboBox.Items.Add(course1);
            this.comboBox.Items.Add(course2);
            this.comboBox.Items.Add(course3);
            this.comboBox.Items.Add(course4);
            this.comboBox.Items.Add(course5);
            this.comboBox.Items.Add(course6);
            this.comboBox.Items.Add(course7);

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            choice = (Course)(this.comboBox.SelectedItem);

            /* Code added that will not allow for the registration of more than 9 credit hours.
             * Also, checks for already registered courses. 
             * If not already registered, it registers student while updating selected courses and credit hours
             * All this will displaying the correct feedback messaging to the student
             */

            if (creditHours >= 9)
            {
                this.textBlock.Text = "You cannot register for more the 9 credit hours.";
            }
            else if (this.listBox.Items.Contains(choice) && choice.IsRegisteredAlready())
            {
                this.textBlock.Text = "You have already registered for this " + choice.ToString() + " course";
            }
            else
            {
                this.listBox.Items.Add(choice);
                choice.SetToRegistered();
                creditHours += 3;
                this.textBox.Text = Convert.ToString(creditHours);
                this.textBlock.Text = "Registration confirmed for course " + choice.ToString();
            }
        }
    }
}
